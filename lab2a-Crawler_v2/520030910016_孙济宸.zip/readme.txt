Task1:
python ./task1_login.py

Task2:
python ./task2.py

Task3:
python task3_crawler_nofilter.py SEED_URL METHOD URLNUMBER
