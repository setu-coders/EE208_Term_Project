测试方法：
cd code
1)
python testBloomFilter.py
测试集为words.txt （摘自维基百科）
2)
python crawler_thread.py -s SEEDURL -thread THREADNUM -page MAXPAGENUM
example:
python crawler_thread.py -s http://www.baidu.com -thread 4 -page 100